# use tabSetpanel
# The Tools one
# funtion one:
# upload usr's original .csv data, ask whether to change the seq name to line name
# change, create a ui to upload the seqName-LineName table (.xlsx) and reheader the LineName
# give a button to transform the strand to the B73 V4 ref format
# give a notification or progressbar when transforming

# usethis::use_package("shiny")
# usethis::use_package("pkgload")
library(openxlsx)
library(shinyFeedback)
library(pacman)
library(R.utils)
library(ggrepel)
library(shiny)
library(tidyverse)
library(magrittr)
library(reactable)
library(showtext)
library(patchwork)
library(gdsfmt)
library(SNPRelate)
library(LEA)
library(colourpicker)
library(shinyWidgets)
library(shinycssloaders)
library(pheatmap)
library(ggstar)
library(shinythemes)
library(gg.gap)
source("http://membres-timc.imag.fr/Olivier.Francois/Conversion.R")
source("http://membres-timc.imag.fr/Olivier.Francois/POPSutilities.R")
options(shiny.maxRequestSize = 100 * 1024^2)

pkgload::load_all(".")

GCA()

# 
# AllFIles <- list.files(
#   './data/'
# )
# 
# for(i in AllFIles){
#   load(str_c('./data/', i))
# 
# }


