

GetPACplot <- function(PCAList, VecWant1, VecWant2, coreLineFile, GroupHighLightFile, SHOWAMP,
                       SizeList, AlphaList, LegendLabelSize,
                       CoreGroupColor, UsrdefaultColor, UserShapes, BackgroundName) {
  
  # pca data
  
  # choose PCs you want to show
  SelectedPC <- str_c('PC', c(VecWant1, VecWant2))
  
  PCA <- PCAList [['Vec']] %>% dplyr::select(c(Line, SelectedPC))
  
  # pca expalation  portion
  
  PCA_axis_labels <- str_c(SelectedPC, ' (', round(PCAList [['portion']] [c(VecWant1, VecWant2)], 2), '%)')
  
  # amp group type
  # AMP_source <-
  # openxlsx::read.xlsx(
  # './AMP-New-ID.xlsx',
  # sheet = 2, colNames = T
  # ) %>% dplyr::select(`Sample-LJY`, Class) %>%
  # mutate(`Sample-LJY` = if_else(`Sample-LJY` == 'DE', 'DE.EX', `Sample-LJY`)) %>%
  # set_names(c('Lines', 'Sub populations')) %>% distinct() %>%
  # mutate(`Sub populations` = 
  # if_else(is.na(`Sub populations`), 'NotClear', `Sub populations`)) %>%
  # filter(!(Lines == 'MO17' & `Sub populations` == 'NotClear')) %>%
  # mutate(Lines = str_replace_all(
  # Lines, 'P6WC', 'PH6WC'
  # )) %>%
  # mutate(Lines = str_replace_all(
  # Lines, 'PH4VC', 'PH4CV'
  # ))
  
  # usethis::use_data(AMP_source)
  
  ## AMP core Lins Files; From User
  AMP_core_lines <- coreLineFile
  #   openxlsx::read.xlsx(
  #     './2023CHN_XY_GB_HighLight_CoreLine_V2.xlsx',
  #     rowNames = F, colNames = T
  #   )
  
  ## HightLight Line Groups; From User
  GroupHighLight <- GroupHighLightFile
    # openxlsx::read.xlsx(
    #   './P3-AMP.xlsx', rowNames = F, colNames = T
    # )
  
  
  # Rm highlightted Line overlapped with AMP Core Line  
  # Rm Line User want to remove 
  GroupHighLight <- GroupHighLight %>%
    filter(!(Line %in% AMP_core_lines$Line)) %>%
    filter(is.na(RmLine))
  
  # merge PCA file with AMP group file
  plot_df <-
    PCA %>% left_join(
      AMP_source %>% dplyr::select(Lines, `Sub populations`),
      by = c('Line' = 'Lines')
    ) %>%
    rename(POP = `Sub populations`) %>%
    mutate(POP = str_c('AMP : ', POP))
  
  # new Line was named by GroupHighLight file
  # 此处可能会产生某些New Line没有POP的情况
  # 主要原因是测序文件中存在一些材料，但是用户提供的GroupHighLight里面未包含
  plot_df2 <-
    plot_df %>% mutate(
      POP = if_else(
        is.na(POP), 
        GroupHighLight$Group[match(Line, GroupHighLight$Line)],
        POP
      )
    )
  
  # All AMP Line Size is set to small; shape to point
  # other Line size to Big; shape to angle
  plot_df3 <-
    plot_df2 %>%
    mutate(Size = if_else(
      Line %in% (AMP_source$Lines), 'S', 'B'
    ),
    Shape = if_else(
      Line %in% (AMP_source$Lines), 'AMP', 'non-AMP'
    )
    )
  
  # -------------- highlight core line --------------
  # including AMP and usr inputs new line
  plot_df3_CoreLine <-
    plot_df3 %>% filter(Line %in% AMP_core_lines$Line)
  
  # core Line is named by core Line file group
  plot_df3_CoreLine$POP <-
    AMP_core_lines$Group [match(plot_df3_CoreLine$Line, AMP_core_lines$Line)]
  
  # core Line size is set to big big
  plot_df3_CoreLine$Size <- 'BB'
  
  # replace the orig core line to new coreline
  plot_df4 <-
    rbind(
      plot_df3 %>% filter(!(Line %in% AMP_core_lines$Line)),
      plot_df3_CoreLine # 重新修改后的core line
    )
  
  # -------------- highlight user want to 
  USER_HIGHLIGHT <-
    GroupHighLight %>% filter(HighLine == 'Yes') %$% Line
  
  # set user want highlight sample Size to Big Big
  plot_df5 <-
    plot_df4 %>% mutate(
      Size = if_else(Line %in% (USER_HIGHLIGHT), 'BB', Size)
    )
  
  # whether not to show amp background
  if(SHOWAMP)
  {
    if(BackgroundName == 'AMP')
    {
      plot_df5 <- plot_df5 %>% filter(!(str_detect(POP, BackgroundName) & Size != 'BB'))
    } else {
      BackgroundLines <-
      GroupHighLight %>% filter(Background == 'Yes') %$% Line
      
      plot_df5 <- plot_df5 %>% filter(!(Line %in% BackgroundLines))
    }
  }
  
  # remove the prefix of AMP Groups 
  plot_df5 <- plot_df5 %>%
    mutate(POP = if_else(
      POP == 'AMP : SS', 'SS',
      if_else(POP == 'AMP : NSS', 'NSS', if_else(
        POP == 'AMP : TST', 'TST', POP
      ))
    ))
  
  table(plot_df5$Size)
  table(plot_df5$Shape)
  table(plot_df5$POP)
  
  # Set Each Group to feat color
  # 可以根据最后plot5的POP信息，自动弹出每个群的颜色输入pickcolor
  # 先从系统默认颜色中设置这些群的颜色
  # 然后让用户自行修改
  # 核心材料的分群颜色
  CoreLineColor <- 
    CoreGroupColor %>%
    set_names(unique(AMP_core_lines$Group))
  
  # Get Each Groups according colors
  # Core Line color use DefaultColor
  # User Line use DeepColor
  UserLineColor <-
  UsrdefaultColor %>% set_names(
    # 如果用户输入的材料分群中有和核心群重叠的，直接排除在外
    setdiff(unique(GroupHighLight$Group), unique(AMP_core_lines$Group)) 
  )
  
  # 这里有个问题，即目前AMP背景的群，有SS，NSS，TST默认的
  # 所以核心自交系群中，必须包含这三个群
  # 以后，如果对AMP有新的认识，可以提供新的AMP分群思路
  # 这个时候可以提供一个AMP群的分群文件，让用户自己分群~
  # 但是这个分群，理论上也要被包含在CoreLine文件中
  
  COLOR_ <- c(UserLineColor, CoreLineColor)
  
  # 既不在AMP中的，也不在用户提供的分群中的材料直接去掉
  plot_df6 <-
  plot_df5 %>% filter(!is.na(POP)) %>%
    # 对于AMP中的Mixed和NotClear群，前面已经将其中属于core line的Group给修改了
    # 所以剩下的都是意义不明的，直接剔除
    filter(!(POP %in% c('AMP : Mixed', 'AMP : NotClear')))
  
  # Set Different Size, alpha, shape to according type
  SIZE_ <- c(SizeList[1],SizeList [2]) %>% set_names(c('BB', 'S'))
  ALPHA_ <- c(AlphaList[1], AlphaList [2]) %>% set_names(c('BB', 'S'))
  
  # 形状我们默认分为AMP和非AMP类
  # 同时，AMP全部设为某一形状，非AMP类全部默认设置为某一形状
  # 如果用户提供的文件中Shapes列，有不为NA的观测值，则将其视为另一种形状
  # 同时把上述形状都提供可修改的参数，让用户自行修改形状（selectinput）
  
  # 用户自定义的Shape设置
  SHAPE_ <-
    AllShapeForm$Value [match(UserShapes, AllShapeForm$Shape)] %>% 
    set_names(
      c(str_c(c('', 'non-'), BackgroundName), GroupHighLight %$% unique(na.omit(Shapes)))
    )
  
  # allow to show chinese font
  showtext_auto()
  
  # Get AMP background
  # AMP背景，必须保证来源是AMP，同时不能是核心材料或者是用户不想highlight的材料
  plot_back <-
    plot_df6 %>% filter(!is.na(POP)) %>%
    filter(str_detect(Shape, BackgroundName)) %>%
    filter(Size == 'S')
  
  # 前景
  plot_fore <-
  plot_df6 %>% anti_join(
    plot_back, by = c('Line' = 'Line')
  )
  
  # 标签
  plot_fore_label <- plot_fore %>% filter(Size == 'BB')
  
  
  ggplot() +
    # 绘制AMP背景
    geom_star(data = plot_back,
                aes_string(x = SelectedPC  [1], y = SelectedPC [2], color = 'POP',
                           alpha = 'Size', size = 'Size', starshape = 'Shape', fill = 'POP'),
                show.legend = F
    ) +
    stat_ellipse(
      data = plot_back,
      aes_string(x = SelectedPC [1], y = SelectedPC [2], color = 'POP'),
      geom = 'path',
      linetype = 2,
      size = 1.5,
      show.legend = F
    ) +
    # 绘制其他材料前景
    geom_star(
      data = plot_fore,
      aes_string(x = SelectedPC [1], y = SelectedPC [2], color = 'POP',
                 alpha = 'Size', size = 'Size', starshape = 'Shape', fill = 'POP'),
      show.legend = T
    ) +
    # 设置这些材料的颜色，形状，透明度，大小等
    scale_starshape_manual(values = SHAPE_, name = NULL) +
    scale_fill_manual(values = COLOR_, name = NULL) +
    scale_color_manual(values = COLOR_, name = NULL) +
    scale_alpha_manual(values = ALPHA_, name = NULL, label = NULL) +
    scale_size_manual(values = SIZE_, name = NULL, label = NULL) +
    guides(
      color = guide_legend(override.aes = list(size = LegendLabelSize [1]), ncol = 1, shape = rep(19, length(COLOR_))),
      fill = guide_legend(override.aes = list(size = LegendLabelSize [1]), ncol = 1, shape = rep(19, length(COLOR_))),
      starshape = guide_legend(override.aes = list(size = LegendLabelSize [1]), ncol = 1),
      alpha = "none",
      size = "none",
    ) + 
    # ggnewscale::new_scale_color() +
    # ggnewscale::new_scale() +
    # 添加材料名标签
    ggrepel::geom_text_repel(
      data = plot_fore_label,
      aes_string(x = SelectedPC [1], y = SelectedPC [2], label = 'Line', color = 'POP'),
      size = LegendLabelSize [2],
      fontface = "bold",
      alpha = 0.8,
      show.legend = F,
      force = T,
      point.padding = 0.5,
      min.segment.length = 0,
      max.overlaps = Inf,
      max.time = 1, max.iter = 1e5,
      segment.size = 0.5,
      inherit.aes = F
    )  +
    # scale_color_manual(values = COLOR_) +
    # guides(color = "none") +
    # 设置主题信息
    theme(
      legend.spacing.y = unit(3, 'mm'),
      panel.grid = element_blank()
    ) +
    theme_bw(base_size = 28, base_line_size = 0.1, base_rect_size = 0.1) +
    labs(x = PCA_axis_labels [1], y = PCA_axis_labels [2])
  
}

