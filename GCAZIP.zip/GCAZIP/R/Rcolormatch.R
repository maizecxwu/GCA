Three_Time_COLOR <- c("#7189BF", "#DF7599", "#FFC785")

Four_Type_color <- c("#7189BF", "#DF7599", "#FFC785", "#72D6C9")

Three_type_COLOR <- c("#9ed088", "#9982bb", "#999c9f")

DeepColor <- c("#8c510a", "#01665e", "#253494", '#ae017e', "#7189BF", "#ffafaf")

# Four_type_COLOR <- c("#cd6598", "#8fabdd", "#bf9100", "#009899")

t_test_color <- c("#7eaac9", "#ffafaf")

Gradient_color <-
  c("#543005",    "#8c510a",    "#bf812d",
    "#dfc27d",    "#f6e8c3",    "#f5f5f5",
    "#c7eae5",   "#80cdc1",    "#35978f",
    "#01665e",    "#003c30")

Gradient_color2 <-
  c(
    "#ffffd9",    "#edf8b1",    "#c7e9b4",
    "#7fcdbb",    "#41b6c4",    "#1d91c0",
    "#225ea8",    "#253494",    "#081d58"
  )

Gradient_color3 <-
  c(
    '#fff7f3',    '#fde0dd',    '#fcc5c0',
    '#fa9fb5',    '#f768a1' ,   '#dd3497',
    '#ae017e',    '#7a0177',   '#49006a'
  )

Gradient_color4 <-
  c(
    '#c10001',    '#fc331c',    '#ff8f00',
    '#ffd221',    '#edff5b',    '#c7e000',
    '#52e000',    '#00b22c',    '#1a9391',
    '#0eacbd',    '#00c4da',    '#4643bb',
    '#610c8c',    '#980fb7',    '#d223fe',
    '#b30347'
  )


col_10<-c("#0079bf","#70b500","#ff9f1a","#eb5a46","#dfcc36",
          "#c377e0","#e773ba","#00ddff","#4dca87","#c4c9cc")

message('color have Three_Time_COLOR, Four_Type_color,
Three_type_COLOR, t_test_color, Gradient_color, Gradient_color2,
Gradient_color3, col_10, PARIE_COLOR, Five_type_color_boxplot, DeepColor, Gradient_color4\n')

Five_type_color_boxplot <- c("#7a9ac8", "#df985d", "#de908a", "#7bc355", "#65c7b4")

PARIE_COLOR <- RColorBrewer::brewer.pal(n = 12, name = 'Paired')
