
# -------------- visual the whole map --------------
# -------------- each gene show one snp

SGFSPlotting <- function(FormattedDat) {
  
  pacman::p_load(showtext)
  showtext_auto()
  
  SAMPLE_ORDER <- colnames(FormattedDat)[-c(1:15)]
  
  plot_df <-
    FormattedDat %>%
    filter(!is.na(pvalue)) %>%
    reframe(
      across(everything(), ~ .x[.data [['pvalue']] == min(.data [['pvalue']])]),
      .by = c(Trait.Type, Trait, real_trait, `Gene.Name`)
    )
  
  plot_df1 <-
    plot_df %>%
    select(`Trait.Type`:`Gene.Name`) %>%
    ungroup() %>%
    select(-real_trait, -Trait) %>%
    gather(key = "Attributes", value = "Types", -`Gene.Name`)
  
  ORDER_GENE <-
    plot_df %>%
    select(`Trait.Type`:`Gene.Name`) %>%
    ungroup() %>%
    select(-real_trait, -Trait) %>%
    arrange(`Trait.Type`) %$% unique(Gene.Name)
  
  plot1 <-
    ggplot(data = plot_df1 %>%
             mutate(Gene.Name = factor(Gene.Name, levels = ORDER_GENE))) +
    geom_tile(aes(x = Attributes, y = `Gene.Name`, fill = Types),
              color = "white"
    ) +
    theme_classic(base_size = 22, base_line_size = 0.1, base_rect_size = 0.1) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
      legend.position = "left",
      axis.text.y = element_blank(),
      axis.ticks = element_blank(),
      axis.title.y = element_blank()
    ) +
    guides(fill = guide_legend(ncol = 1, title = NULL))
  
  plot_df2 <-
    plot_df %>%
    ungroup() %>%
    select(`Gene.Name`, 16:ncol(.)) %>%
    gather(key = "Sample", value = "Favor_num", -`Gene.Name`)
  
  plot2 <-
    ggplot(data = plot_df2 %>%
             mutate(
               Gene.Name = factor(Gene.Name, levels = ORDER_GENE),
               Sample = factor(Sample, levels = SAMPLE_ORDER),
               Favor_num = as.character(Favor_num)
             )) +
    geom_tile(aes(x = Sample, y = `Gene.Name`, fill = Favor_num),
              color = "white"
    ) +
    scale_fill_manual(values = c("0" = "white", "1" = "#41b6c4", "2" = "#081d58")) +
    theme_classic(base_size = 22, base_line_size = 0.1, base_rect_size = 0.1) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1))
  
  plot1 + plot2 + plot_layout(
    nrow = 1,
    widths = c(0.2, 1),
    guides='collect'
  ) & theme(legend.position = 'right')
}
