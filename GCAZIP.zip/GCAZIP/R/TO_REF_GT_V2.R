
TO_REF_GT_V2_VCF <- function(CsvGt) {
  
  # -------------- save the vcf format GT
  DAT_prepared <-
    CsvGt %>% left_join(
      AMP_sample@fix %>% as_tibble() %>%
        mutate(across(1:2, as.numeric)) %>% 
        select(1:5) %>% rename(`#CHROM` = CHROM)
    ) %>% select(1:3, REF, ALT, everything())
  
  DAT_VCF <-
    DAT_prepared %>% t %>% as.data.frame() %>% 
    map_df(mutate_num_allele_to_chr, NUM_TO_CHR = FALSE) %>%
    t %>% as_tibble() %>% set_names(colnames(DAT_prepared)) %>%
    mutate(across(1:2, as.numeric))
  
  # -------------- overlap site inf
  # 因为本芯片主要基于AMP进行开发，所以要与AMP取交集
  # 从而使后续分析可以顺利进行
  OVERLAP_SNP_ID <-
    intersect(DAT_VCF$ID, AMP_sample@fix [, 'ID'])
  # 这个地方不知道原先为什么要和AMP取交集，因此这里取消先
  DAT_VCF_V2 <- DAT_VCF %>% filter(ID %in% OVERLAP_SNP_ID)
  
  AMP_sample@gt <-
    cbind(rep("GT", nrow(DAT_VCF_V2)), DAT_VCF_V2 %>% select(-c(1:5))) %>%
    as.matrix()
  
  colnames(AMP_sample@gt) [1] <- 'FORMAT'
  
  AMP_sample@fix <-
    AMP_sample@fix [match(DAT_VCF_V2$ID, AMP_sample@fix [, 'ID']), ]
  
  AMP_sample
  
}

TO_REF_GT_V2 <- function(GT) {
  
  REV_wrong_strand <- function(VEC) {
    
    if(as.logical(tail(VEC, 1)) & !is.na(as.logical(tail(VEC, 1))))
    {
      REV_BASE_FUN(VEC [-length(VEC)])
    } else {
      VEC [-length(VEC)]
    }
  }
  
  REV_GT <-
    GT %>% left_join(
      All_SNP_INF %>% select(ID, REV)
    ) %>% select(-c(1:3)) %>% t %>% as_tibble() %>%
    map_dfc(REV_wrong_strand)
  
  REV_GT_V2 <-
    cbind(
      GT %>% select(1:3),
      REV_GT %>% t %>% as_tibble() %>%
        set_names(colnames(GT) [-c(1:3)])
    )
  
  list(
    CsvFormat = REV_GT_V2,
    vcfFormat = TO_REF_GT_V2_VCF(REV_GT_V2)
  )
  
}

