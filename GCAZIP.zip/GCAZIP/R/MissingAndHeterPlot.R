
# -------------- Missing Rate evalutate -------------- 
# -------------- each sample 
cal_each_col_na_percent <- function(Vec) {
  sum(is.na(Vec)) / length(Vec)
}

# -------------- Heterozygosity -------------- 
# -------------- each sample
cal_each_col_Heterozygosity_percent <- function(Vec) {
  Vec <- na.omit(Vec)
  sum(str_sub(Vec, 1, 1) != str_sub(Vec, 2, 2)) / length(Vec)
}

# Main plotting funcion 
get_sample_Ms_or_Hete <- function(Functs, Xlab = 'MSRT', plotdata) {
  
  cal_Func <- match.fun(Functs)
  
  plot_df <-
    plotdata %>% select(-c(1:3)) %>%
    map_df(cal_Func) %>% t %>%
    as.data.frame() %>% mutate(Sample = rownames(.))
  
    showtext_auto()
  
    ggplot(plot_df %>% arrange(-V1) %>% mutate(Sample = factor(Sample, levels = Sample))) +
    geom_bar(aes(y = Sample, x = V1), stat = 'identity',
             color = NA, fill = t_test_color [1]) +
    theme_bw(base_size = 16, base_line_size = 0.1, base_rect_size = 0.1) +
    labs(x = Xlab, y = 'Sample ID')
  
}

