# PCAcal <- function(VCFfile) {
#   VCFfileforPS <- AMP_sample
#   
#   TmpVCFfile1 <- tempfile(fileext = '.vcf.gz')
#   
#   vcfR::write.vcf(VCFfileforPS, TmpVCFfile1)
#   
#   TmpGDSfile1 <- tempfile()
#   
#   snpgdsVCF2GDS(TmpVCFfile1, TmpGDSfile1, method="biallelic.only")
#   
#   genofile <- snpgdsOpen(TmpGDSfile1)
#   
#   pca <- snpgdsPCA(genofile, num.thread=2)
#   
#   pc.percent <- pca$varprop*100
#   
#   PCAfiles <-
#     data.frame(sample.id = pca$sample.id,
#                EV1 = pca$eigenvect[,1],    # the first eigenvector
#                EV2 = pca$eigenvect[,2],    # the second eigenvector
#                stringsAsFactors = FALSE)
#   
# }
# 
# 
# # ibd
# ibd <- snpgdsIBDMoM(genofile)
# 
# ibd.coeff <- snpgdsIBDSelection(ibd)
# 
# # ibs
# ibs <-  snpgdsIBS(genofile, num.thread=2)
# 
# # kinship
# ibd.robust <- snpgdsIBDKING(genofile, num.thread=2)
# 
# dat <- snpgdsIBDSelection(ibd.robust)
# 
# head(dat)
# 
# # cluster by ibs matrix
# 
# ibs.hc <- snpgdsHCluster(snpgdsIBS(genofile, num.thread=2))
# 
# rv <- snpgdsCutTree(ibs.hc)
# 
# rv$samp.group
# 
# plot(rv$dendrogram, leaflab="none")
# 
# ### population structure
# 
# R.utils::gunzip(TmpVCFfile1, 'test.vcf', remove = T, overwrite = T)
# 
# LEA::vcf2geno(input.file = 'test.vcf', output = "test.geno")
# 
# obj.snmf = snmf("test.geno", K = 3, alpha = 100, project = "new")
# 
# qmatrix = Q(obj.snmf, K = 3)
# 
# barplot(t(qmatrix), col = c("orange","violet","lightgreen"), border = NA, space = 0,
#         xlab = "Individuals", ylab = "Admixture coefficients")
# 
# #
# obj.snmf = snmf("test.geno", K = 1:8, ploidy = 2, entropy = T,
#                 alpha = 100, project = "new")
# 
# plot(obj.snmf, col = "blue4", cex = 1.4, pch = 19)
# 
# 
# 








