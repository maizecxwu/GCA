

PlotModifyUI <- function(id) {
  tagList(
    sliderInput(NS(id, 'Ysize'), label = 'Y-size', min = 1, max = 40, value = 20),
    sliderInput(NS(id, 'Xsize'), label = 'X-size', min = 1, max = 40, value = 20),
    sliderInput(NS(id, 'AxisTitleSize'), label = 'Axis-Title-Size', min = 1, max = 40, value = 26)
  )
}

PlotModifyServer <- function(id, ggPlotGraph) {
  moduleServer(id, function(input, output, session){
    stopifnot(is.reactive(ggPlotGraph))
    reactive({
      ggPlotGraph() +
        theme(
          axis.text.x = element_text(size = input$Xsize),
          axis.text.y = element_text(size = input$Ysize),
          axis.title = element_text(size = input$AxisTitleSize, face = 'bold')
        )
    })
  })
}