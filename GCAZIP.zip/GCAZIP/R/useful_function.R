quick_write_table <- function(file_name, save_path) {
    write.table(file_name, save_path, row.names = F, col.names = T, sep = "\t", quote = F)
}

message('quick_write_table() : quick write the file, 2 params: 1- file_name, 2-savepath\n')

quick_read_table <- function(save_path, ...) {
    read.table(save_path, header = T, sep = "\t", check.names = F, ...)
}

print('quick_read_table() : quick read the file, 1 params: 1- file_name')
message('Note: default param header = T, sep = "\t", check.names = F\n')

# -------------- 给出两个数字n1，n2，创建一个从1到n1，1到n2两两匹配的数据框
get_1_n_pairs_funcs <- function(n1, n2) {
    data.frame(rep(1:n1, each = n2), rep(1:n2, n1))
}
message('get_1_n_pairs_funcs() : two num, 1:n1, 1:n2, paired df including 1,1; 2 params: n1 n2\n')

# sacle the data to 0 ~ 1
scale_to_0_1 <- function(Vec) {
    (Vec - min(Vec, na.rm = T)) / (max(Vec, na.rm = T) - min(Vec, na.rm = T))
}
message('scale_to_0_1() : sacle the Vec to 0 ~ 1; 1 params: Vec\n')


# -------------- 得到18个时期对应的具体时期
get_the_time <- function(data) {
    case_when(
        data <= 6 ~ "Early",
        data >= 13 ~ "Late",
        data >6 & data < 13 ~"Mid",
        TRUE ~ as.character(data)
    )
}

message('get_the_time() : get 1:18 to Early, Mid, Late chr, 1 params: n \n')

# -------------- 得到对应表型、时期的表型值
get_the_pheno_data_value <- function(Trait_Name_yes, Trait_Time_yes,
Pheno_dataXX = Pheno_data, TIXX = TI) {
    Pheno_dataXX %>%
    filter(Trait_Name %in%
    c(TIXX %>% filter(Trait_Name %in% Trait_Name_yes,
    Trait_Time %in% Trait_Time_yes) %$% Trait_ID)) %>%
    t %>% as.data.frame() %>% mutate(ROW = rownames(.))
}
message('get_the_pheno_data_value() : get Trait n Time n2 value, 2 params: Trait n Time n2\n')

rm_outliner_value <- function(values) {
    BOUND = boxplot.stats(values)[['stats']][c(1, 5)]
    values[values < BOUND[1] | values > BOUND[2]] <- NA
    values
}

message('rm_outliner_value() : rm boxplot.outliner value, 1 params: Vec\n')

# -------------- 使用时请将第一列改为变量，第二列改为数据
get_P_value <- function(data, sign_dig = 2) {
  data <-
  data %>% set_names(c("Var", "value"))
  Vars <- data %$% Var %>% unique
  t.test(data %>% filter(Var == Vars[1]) %$% value,
  data %>% filter(Var == Vars[2]) %$% value)$p.value %>%
  signif(., digits = sign_dig)
}

print('get_P_value() : get t-test pvalue from 2 variable, 1 params: df')
message('the df include 2 col, first is var, second is value\n')

# 最小值取最大， 最大值取最小
S_cel_B_flr <- function(x, Len = 4) {
  Mid <- c(floor(min(x, na.rm = T)), ceiling(max(x, na.rm = T)))
  list(
    limits = Mid,
    Breaks = seq(Mid[1], Mid[2], length.out = Len) %>% as.integer
  )
}

print('S_cel_B_flr() : get the int ceiling min and floor max from a vec , 2 params: Vec, seqlen')
message('the function return limits and Breaks for sacle_x(y)_continuos\n')

# input your var list，get all combination data.frame
get_all_combination <- function(var_list, help = F) {
if(help) message("input your var list，get all combination data.frame") else {
# orig_oder <- var_list %>% names()
# New_order <-
# var_list %>% lapply(length) %>% unlist %>% sort %>% names()

var_list_df <- data.frame()
for(i in 2:length(var_list))
{
  if(i == 2)
  {
    var_list_df <- cbind(
      rep(var_list[[i - 1]], length(var_list[[i]])),
      rep(var_list[[i]], each = length(var_list[[i - 1]]))
      )
  } else {
    var_list_df <- cbind(
      var_list_df [rep(1:nrow(var_list_df), length(var_list[[i]])), ],
      rep(var_list[[i]], each = nrow(var_list_df))
    )
  }
}

var_list_df <- as.data.frame(var_list_df) %>%
                set_names(str_c("Var", 1:length(var_list)))

if(!is.null(names(var_list)))
{
  var_list_df %>%
  set_names(names(var_list))
} else {
  var_list_df
}  
}
}

print('get_all_combination() : get all combination from n var cols , 1 params: list')
message('the function return df including all combinations\n')

# -------------- 替换allele到数字型结果

replace_chr_to_num <- function(vect, Gtype = 'HMP') {
  if(Gtype == 'HMP')
  {
    ALltype <- str_dup(str_split(vect[2],'/', simplify = T),2)
    vect[vect == ALltype[1]] <- "A/A"
    vect[vect == ALltype[2]] <- "G/G"
    vect
  } else {
    vect[vect == '0/0'] <- "A/A"
    vect[vect == '1/1'] <- "G/G"
    vect[vect == '0/1'] <- "./."
    vect
  }

}

# -------------- 计算两个snp的LD
get_r2_ld_2snp <- function(data, RETURN_adjacent = TRUE) {
    MID_df <-
    data %>% t %>% as.data.frame() %>%
    mutate(across(everything(), replace_chr_to_num, Gtype = 'vcf')) %>%
    set_names(.[2, ]) %>% .[-c(1:11), ]
    MID_df[MID_df == "NN"] <- NA
    MID_df[MID_df == "./."] <- NA

    if(RETURN_adjacent)
    {
      genetics::LD(genetics::makeGenotypes(MID_df))$`R^2` %>%
      . [-nrow(.), -1] %>% diag()
    } else {
      genetics::LD(genetics::makeGenotypes(MID_df))$`R^2`
    }

}

print('replace_chr_to_num() : replace The GT to base (A/A;G/G)')
message('vect - The GT of 1 line \n')
message('Gtype - HMP or VCF')

print('get_r2_ld_2snp() : cal a orig vcf data snp LD matrix ')
message('data - The original vcf data (read from data.table; not read.vcfR) \n')
message('RETURN_adjacent - TRUE or FALSE; if TRUE, only return adjacent 2 snps LD')

# -------------- read all files with same headers -------------- 

read_ALL_files <- function(FILELS) {

read_single_files <- function(FILEE) {
read.table(
FILEE,
header = T, sep = '\t', check.names = F, comment.char = ''
)
}

map_dfr(FILELS, read_single_files)

}

print('read_ALL_files() : read all files with same headers and rbind')
message('FILES - the file list; must each file have same headers \n')

# get_reverse_strand_base

get_reverse_strand_base <- function(BASE) {
case_when(
BASE == 'A' ~ 'T',
BASE == 'T' ~ 'A',
BASE == 'C' ~ 'G',
BASE == 'G' ~ 'C'
)
}
print('get_reverse_strand_base() : get_reverse_strand_base')
message('only A T C G, 4 base input \n')


# -------------- judge_A_VEC_continuous_block -------------- 

judge_A_VEC_continuous_block <- function(VEC) {
BREAKS <-
which((VEC [-1]  - VEC [-length(VEC)]) != 1)

map2(c(1, BREAKS + 1), c(BREAKS, length(VEC)),
~ VEC [.x:.y]
)
}

print('judge_A_VEC_continuous_block() : judge a VEC continous BLOCK num')
message('only 1 input, a VEC; return a list\n')


# -------------- THE 

get_each_MAX_median <- function(MAX_VALUE) {
median(seq(1, MAX_VALUE))
}


print('get_each_MAX_median() : get a 1 - Value (MAX), median value')
message('only 1 input, a Value; return a median\n')


# -------------- REV ALL minus strand Base
REV_BASE_FUN <- function(BASE) {
case_when(
BASE == 'AA' ~ 'TT',
BASE == 'TT' ~ 'AA',
BASE == 'CC' ~ 'GG',
BASE == 'GG' ~ 'CC',
BASE == 'AT' ~ 'TA',
BASE == 'AC' ~ 'TG',
BASE == 'AG' ~ 'TC',
BASE == 'TA' ~ 'AT',
BASE == 'TC' ~ 'AG',
BASE == 'TG' ~ 'AC',
BASE == 'CA' ~ 'GT',
BASE == 'CT' ~ 'GA',
BASE == 'CG' ~ 'GC',
BASE == 'GA' ~ 'CT',
BASE == 'GT' ~ 'CA',
BASE == 'GC' ~ 'CG',
)
}

print('REV_BASE_FUN() : reverse +(-) strand base to -(+) strand base')
message('only 1 input, a Vec with 2 base \n')

mutate_num_allele_to_chr <- function(Vec, NUM_TO_CHR = TRUE) {
if(NUM_TO_CHR)
{
Vec [Vec == '0/0'] <- str_dup(Vec [3], 2)
Vec [Vec == '1/1'] <- str_dup(Vec [4], 2)
Vec [Vec == '0/1'] <- str_c(Vec [3], Vec [4])
} else {
Vec [Vec == str_dup(Vec [4], 2)] <- '0/0'
Vec [Vec == str_dup(Vec [5], 2)] <- '1/1'
Vec [Vec == str_c(Vec [4], Vec[5]) | Vec == str_c(Vec [5], Vec[4]) ] <- '0/1'

Vec [setdiff(c(6:length(Vec)), which(Vec %in% c('0/0', '1/1', '0/1')))] <- NA
}

Vec
}

print('mutate_num_allele_to_chr() : 0/0 gt to A T C G or REVERSE')
message('param 1, a Vec with gt; if NUM, the REF gt in POS 3, or in POS 4')
message('param 2 - NUM_TO_CHR: TRUE or FALSE\n')

# -------------- rm Outliners function
rm_outliners_funcs <- function(Vec, Mode = 'Box') {

if(Mode == 'Box')
{
Vec_range <- range(boxplot.stats(Vec) [['stats']])
Vec [Vec< Vec_range[1] | Vec > Vec_range [2]] <- NA
Vec
} else {
Vec_range <- c(mean(Vec, na.rm = T) - 3 * sd(Vec, na.rm = T),
mean(Vec, na.rm = T) + 3 * sd(Vec, na.rm = T)
)
Vec [Vec< Vec_range[1] | Vec > Vec_range [2]] <- NA
Vec
}
}

print('rm_outliners_funcs() : rm the outliners data point from a vector')
message('param 1, a Vec (numeric)')
message('param 2 - methods, default Box, or sd')



# -------------- All base combination
AllBaseCombinations <-
  function() {
    expand.grid(x = c('A', 'T', 'C', 'G'), y = c('A', 'T', 'C', 'G'), stringsAsFactors = F) %$%
      str_c(x, y)
  }











