
## plot heat map
PlotTriheatmaps <- function(DATS) {
  
  VARNAME <- names(DATS)[3]
  
  if(VARNAME == 'IBS')
  {
    NASSS <- DATS %>% group_by(ID1) %>%
      summarise(NAs = sum(is.na(.data [[VARNAME]]))) %>%
      arrange(NAs) %$% ID1
    
    DATS <- 
    DATS %>% mutate(
      ID1 = factor(ID1, levels = NASSS),
      ID2 = factor(ID2, levels = NASSS)
    )
  } else {
    NASSS <-
    map(
      c('ID1', 'ID2'),
      ~ DATS %>% group_by(.data [[.x]]) %>% summarise(count = n()) %>%
        arrange(count) %$% get(.x)
    )
    DATS <- 
      DATS %>% mutate(
        ID1 = factor(ID1, levels = rev(NASSS[[1]])),
        ID2 = factor(ID2, levels = NASSS[[2]])
      )
  }

  ggplot(
    DATS
  ) +
    geom_tile(
      aes(
        x = ID1, y = ID2, fill = .data [[VARNAME]]
      ), color = NA
    ) +
    scale_x_discrete(position = 'top') +
    scale_fill_gradientn(colors = Gradient_color2, na.value = NA) +
    theme_classic(base_size = 18, base_line_size = 0.1, base_rect_size = 0.1) +
    theme(axis.ticks = element_blank(),
          axis.text.x = element_text(angle = 90, vjust = 0))
}

## plot Barplot

PlotBarPlot <- function(DATS, PCname, TextSize) {
  plotdf2 <-
    cumsum(
      as.numeric((DATS %$% sort(table(arrangeBY)) / nlevels(DATS$PC)))
    )
  
  plotdf3 <-
    data.frame(
      x = 0.5,
      y = (
        (plotdf2 - c(0, plotdf2 [-length(plotdf2)])) / 2
      ) + c(0, plotdf2 [-length(plotdf2)]),
      label = (
        DATS %>% mutate(arrangeBY = fct_inorder(as.character(arrangeBY))) %>%
          group_by(arrangeBY) %>% summarise(counts = n() / length(PCname)) %>%
          arrange(arrangeBY) %$% str_c(PCname, ' (n=', round(counts, 0), ')')
      )
    )
  
  p1 <-
  ggplot(DATS) +
    geom_bar(aes(x = value, y = ID, fill = PC), stat = 'identity', color = NA) +
    theme_minimal(base_size = 18, base_line_size = 0.5, base_rect_size = 0.5) +
    theme(
      axis.ticks.y = element_blank(),
      legend.position = 'none',
      legend.title = element_blank(),
      panel.grid = element_blank(),
      axis.text.x = element_blank(),
      plot.title = element_text(hjust = 0.5, size = TextSize * 3.5, face = 'bold')
    ) + 
    scale_x_continuous(expand = c(0, 0)) +
    geom_hline(
      yintercept = plotdf2 + 0.5, size = 1, color = 'white', linetype = 1
    ) +
    labs(x = NULL, y = NULL, title = str_c('K = ', length(PCname)))
  
  p2 <- 
    ggplot(DATS) +
    geom_bar(aes(x = value, y = ID), fill = NA, stat = 'identity', color = NA) +
    scale_x_continuous(expand = c(0, 0)) +
    theme_void() +
    geom_text(
      plotdf3, mapping = aes(x = x, y = y, label = label), inherit.aes = F,
      size = TextSize, color = 'black', fontface = 'bold'
    )
    
  p2 + p1 + plot_layout(
    design = "
    22211
    "
  )
  
  # gg.gap(
  #   plot = p,
  #   segments = rbind(plotdf2, plotdf2 + 1) %>% as.data.frame() %>% as.list(),
  #   ylim = c(0, max(plotdf2) + 1)
  # )

}
