AllShapeForm <-
  data.frame(
    Value = as.numeric(ggstar::show_starshapes()$plot_env[['dat2']] [['p']]),
    Shape = ggstar::show_starshapes()$plot_env[['dat1']] [['label']]
  )
