
SelectSampleUI <- function(id) {
  pickerInput(
    NS(id, 'SampleName'), label = 'Sample Name', 
    choices = NULL,
    selected = NULL,
    options = list(
      `actions-box` = TRUE,
      `selected-text-format` = "count > 3"
    ), 
    multiple = TRUE
  )
}

SelectSampleServer <- function(id, Datas) {
  moduleServer(id, function(input, output, session) {
    
    stopifnot(is.reactive(Datas))
    
    observeEvent(Datas(), {
      AllIDS <- unique(c(Datas() %$% c(ID1, ID2)))
      updatePickerInput(
        session = session, inputId = 'SampleName', choices = AllIDS,
        selected = AllIDS
      )
    })

    reactive({
      req(input$SampleName)
      Datas() %>%
        filter(
          ID1 %in% input$SampleName,
          ID2 %in% input$SampleName
        )
    })
  })
}

