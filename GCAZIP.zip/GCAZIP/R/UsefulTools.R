


PickerInputNull <- function(ids, labels) {
  pickerInput(
    inputId = ids,
    label = labels, 
    choices = NULL,
    selected = NULL,
    options = list(
      `actions-box` = TRUE,
      `selected-text-format` = "count > 3"
    ), 
    multiple = TRUE
  )
}

NewSwitch <- function(..., Statss = 'info', defaultValue = FALSE) {
  materialSwitch(
    value = defaultValue,
    status = Statss,
    ...
  )
}

readextFileUI <- function(id, format = ".csv") {
  fileInput(NS(id, 'file'), str_c('Upload ', id, ' file!'), accept = c(format))
}

readextFileServer <- function(id) {
  moduleServer(id, function(input, output, session) {
    reactive({
      req(input$file)
      ext <- tools::file_ext(input$file$name)
      switch(ext,
             csv = vroom::vroom(input$file$datapath, delim = ',', .name_repair = 'minimal'),
             xlsx = openxlsx::read.xlsx(input$file$datapath, rowNames = F, colNames = T),
             vcf = vcfR::read.vcfR(input$file$datapath, verbose = F),
             gz = vcfR::read.vcfR(input$file$datapath, verbose = F),
             validate('Invaild file; Please upload a .csv file')
      )
    })
  })
}

HeatMapUI <- function(id) {
  fluidRow(
    h3(strong('Transformed Data heatmap show')),
    column(
      3,
      PickerInputNull(NS(id, 'SampleNames'), 'Choose Sample Name?'),
      numericInput(NS(id, 'RandomNsnp'), 'how many Snps to show?', value = 1000),
      sliderInput(NS(id, 'BaseFont'), 'Sample font size', min = 2, max = 20, value = 10),
      h4(textOutput(NS(id, 'SampleSNPCount')))
    ),
    column(
      9,
      shinycssloaders::withSpinner(
        plotOutput(NS(id, 'heatmaps'), height = "800px")
      )
    )
  )
  
}


HeatMapServer <- function(id, VCFDATSSS) {
  moduleServer(id, function(input, output, session) {
    
    stopifnot(is.reactive(VCFDATSSS))
    
    observeEvent(VCFDATSSS(), {
      # freezeReactiveValue(input, "SampleNames")
      updatePickerInput(
        session = session, inputId = 'SampleNames', choices = colnames(VCFDATSSS()@gt) [-1],
        selected = colnames(VCFDATSSS()@gt) [-1]
      )
    })
    
    output$heatmaps <- renderPlot({
      req(VCFDATSSS(), input$SampleNames, cancelOutput = TRUE)
      PheatMapplot(
        VCFDATSSS(), SampleName = input$SampleNames,
        RandomSize = input$RandomNsnp, SampletextSize = input$BaseFont
      )
    })
    
    output$SampleSNPCount <- renderText({
      req(VCFDATSSS(), cancelOutput = TRUE)
      str_c('Sample Count: ', (ncol(VCFDATSSS()@gt) -1), '    ',
            'SNP Count: ', nrow(VCFDATSSS()@gt)
      )
    })
    
  })
}

downloadUI <- function(id, labels) {
  downloadBttn(NS(id, 'download'), labels, style = 'material-flat', size = 'sm')
}

downloadServer <- function(id, Filename, Files, fileExt = 'csv', ...) {
  moduleServer(
    id,
    function(input, output, session) {
      output$download <- 
        downloadHandler(
          filename = function() {
            Filename
          },
          content = function(file) {
            if(fileExt == 'csv')
            {
              vroom::vroom_write(Files, file, delim = ',')
            } else if(fileExt %in% c('vcf', 'vcf.gz'))
            {
              id <- showNotification('vcf.gz file Downloading!', duration = NULL)
              on.exit(removeNotification(id), add = T)
              vcfR::write.vcf(Files, file)
            } else if(fileExt == 'xlsx')
            {
              openxlsx::write.xlsx(Files, file, rowNames = F, colNames = T)
            } else {
              ggsave(
                plot = Files, filename = file, ...
              )
            }
          }
        )
    }
  )
}

# Picture dowloading modal

PicturedownloadUI <- function(id, Labelss) {
  actionBttn(NS(id, 'Pdownload'), Labelss)
}

PicturedownloadServer <- function(id, FILES) {
  moduleServer(
    id, function(input, output, session) {
      
      observeEvent(input$Pdownload, {
        showModal(
          modalDialog(
            title = strong("Please input Wdith, Height, PICTURE NAME"),
            footer = fluidPage(style = "text-align: left;",
              fluidRow(
                column(width = 6,
                       textInput(NS(id, 'Name'), 'FILENAME')
                ),
                column(width = 6,
                       textInput(NS(id, 'device'), 'PICTURE TYPE')
                )
              ),
              fluidRow(
                column(width = 6,
                  numericInput(NS(id, "width"), 'WIDTH', value = 10, min = 1, max = 50)
                ),
                column(width = 6,
                       numericInput(NS(id, "height"), "HEIGHT", value = 10, min = 1, max = 50)
                )
              ),
              fluidRow(
                column(width = 6,
                  downloadUI(NS(id, 'downloadpicture'), 'Download!')
                ),
                column(width = 6, style = "text-align: right;",
                  actionBttn(NS(id, "ok"), "Finish", style = "material-flat")
                )
              )
            )
          )
        )
      })
      
      observeEvent(input$ok, {
       removeModal()
      })
      
      downloadServer(
        'downloadpicture', input$Name, FILES, fileExt = tools::file_ext(input$Name),
        width = input$width, height = input$height, device = input$device
      )
    }
  )
}





