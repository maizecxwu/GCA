
# Get Gds File From Vcf format
GetgdsFile <- function(VCFfile) {
  TmpVCFfile1 <- tempfile(fileext = '.vcf.gz')
  
  vcfR::write.vcf(VCFfile, TmpVCFfile1)
  
  TmpGDSfile1 <- tempfile()
  
  snpgdsVCF2GDS(TmpVCFfile1, TmpGDSfile1, method="biallelic.only")
  
  on.exit(rm(TmpVCFfile1, TmpGDSfile1), add = T)
  
  return(snpgdsOpen(TmpGDSfile1))
  
}

# IBD
ibdCal <- function(gdsData) {
  
  ibd <- snpgdsIBDMoM(gdsData)
  
  snpgdsIBDSelection(ibd)
}

# IBS
ibsCal <- function(gdsData) {
  
  ibs <-  snpgdsIBS(gdsData, num.thread=2)
  
  ibs$ibs [lower.tri(ibs$ibs, diag = FALSE)] <- NA
  
  ibs$ibs %>%
    as_tibble() %>% set_names(ibs$sample.id) %>%
    mutate(ID1 = ibs$sample.id) %>%
    pivot_longer(
      cols = all_of(ibs$sample.id), names_to = 'ID2', values_to = 'IBS'
    )
}

# Kinship
kinshipCal <- function(gdsData) {
  
  ibd.robust <- snpgdsIBDKING(gdsData, num.thread=2)
  
  snpgdsIBDSelection(ibd.robust) %>% select(-IBS0)
}

# admixture

AdmixtureCal <- function(VCFfiles, Knum) {
  
  TmpVCFfile1 <- tempfile(fileext = '.vcf.gz')
  
  vcfR::write.vcf(VCFfiles, TmpVCFfile1)
  
  TmpVCFfile2 <- tempfile(fileext = '.vcf')
  
  R.utils::gunzip(TmpVCFfile1, TmpVCFfile2, remove = T, overwrite = T)
  
  rm(TmpVCFfile1)
  
  TmpVCFfile3 <- tempfile(fileext = '.geno')
  
  LEA::vcf2geno(input.file = TmpVCFfile2, output = TmpVCFfile3)
  
  rm(TmpVCFfile2)
  
  obj.snmf = snmf(TmpVCFfile3, K = Knum, alpha = 100, project = "new")
  
  rm(TmpVCFfile3)
  
  tempdata <- Q(obj.snmf, K = Knum) %>% as_tibble() %>%
    set_names(str_c('PC', 1:ncol(.))) %>%
      mutate(
        arrangeBY = apply(., 1, function(x) which(x == max(x))),
        ID = colnames(VCFfiles@gt) [-1]
      )
  
  arrangeBYlevels <- tempdata %>% group_by(arrangeBY) %>% summarise(counts = n()) %>%
    arrange(counts) %$% arrangeBY
  
  map_dfr(arrangeBYlevels, ~ tempdata %>% filter(arrangeBY == .x) %>%
            arrange(- .data [[str_c('PC', .x)]])) %>% 
    mutate(ID = factor(ID, levels = ID)) %>% 
    pivot_longer(
          cols = all_of(names(.) [1:(ncol(.) - 2)]),
          names_to = 'PC', values_to = 'value'
        ) %>%
    mutate(PC = factor(PC, levels = str_c('PC', arrangeBYlevels)))
}


## PCA calculate
GetPCA <- function(gdsData) {
  
  pca <- snpgdsPCA(gdsData, num.thread=2)
  
  pc.percent <- pca$varprop*100
  
  PCAfiles <-
    cbind(
      tibble(Line = pca$sample.id),
      pca$eigenvect %>% as_tibble() %>%
        set_names(
          str_c('PC', 1:ncol(.))
        )
    )
  
  list(
    Vec = PCAfiles,
    portion = pc.percent
  )
}


