


GetAllSampleFunctionGene <- function(GT) {
  
  FunSnpAll_V2 <-
    FunSnpInf %>%
    filter(!is.na(Increase_base)) %>%
    select(ID, `Gene.ID.(V4)`, Trait, Trait.Type, real_trait, ref, alt, Increase_base) %>%
    left_join(TraitFavorBase, by = c("real_trait" = "Trait")) %>%
    mutate(
      Decrease_base = if_else(
        ref == Increase_base, alt, ref
      )
    ) %>%
    mutate(
      Favor_base =
        if_else(value_dir == "up", Increase_base, Decrease_base)
    )
  
  FunSnpID <-
    FunSnpAll_V2$ID %>% unique()
  
  GT_FunSnp <-
    GT %>% filter(ID %in% FunSnpID)
  
  # -------------- check each snp-gene-trait favor result
  
  ScreenSnpFavorAllLine <- function(SnpTrait_ORDER) {
    INF <- FunSnpAll_V2[SnpTrait_ORDER, ] %>% as.character()
    
    if(any(INF[1] %in% GT$ID))
    {
      GT %>%
        filter(ID == INF[1]) %>%
        .[-c(1:3)] %>%
        str_split("") %>%
        map_int(., ~ sum(.x == INF[13], na.rm = T))
    }

  }
  
  FunSnpAll_V2 <- FunSnpAll_V2 %>% filter(ID %in% GT$ID)
  
  AllLineFunSnpNum <-
    map(
      1:nrow(FunSnpAll_V2),
      ScreenSnpFavorAllLine
    )
  
  AllLineFunSnpNum_V1 <-
    do.call(rbind.data.frame, AllLineFunSnpNum) %>%
    set_names(colnames(GT_FunSnp)[-c(1:3)]) %>%
    cbind(FunSnpAll_V2, .)
  
  AllLineFunSnpNum_V2 <-
    AllLineFunSnpNum_V1 %>%
    mutate(across(
      everything(),
      ~ str_replace_all(.x, "\r\n", "")
    )) %>%
    mutate(across(
      everything(),
      ~ str_replace_all(.x, "\n", "")
    ))
  
    AllLineFunSnpNum_V2 %>%
    left_join(FunSnpInf_Pvalue) %>%
    select(1:13, `Gene.Name`, pvalue, everything()) %>%
    mutate(
      `Gene.Name` =
        if_else(
          is.na(`Gene.Name`), `Gene.ID.(V4)`, `Gene.Name`
        )
    )
}

# 
# FunSnpInf_PvalueV2 %>%
#   select(-c(
#     ref, alt, Increase_base, Trait_type, value_dir, trait2, Decrease_base,
#     Favor_base
#   ))
  

