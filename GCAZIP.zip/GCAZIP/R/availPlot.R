
## 改造思路：拆分为两个新模块
# 把修改图的信息独立出来，即根据给的图（ggplot2）进行图信息修改

availPlotUI <- function(id) {
  tagList(
    pickerInput(
      inputId = NS(id, 'Sample'),
      label = 'Samples', 
      choices = NULL,
      selected = NULL,
      options = list(
        `actions-box` = TRUE,
        `selected-text-format` = "count > 3"
      ), 
      multiple = TRUE
    ),
    uiOutput(NS(id, 'Gene'))
  )
}

availPlotServer <- function(id, DataFrom, Type = 'Missing Rate', Analysis = 'Basic') {
  moduleServer(id, function(input, output, session) {
    stopifnot(is.reactive(DataFrom))
    
    AllLines <- reactive({
      # req(Actived())
      if(Analysis == 'Basic') {
        c(1:3)
      } else {
        c(1:15)
      }
    })
    
    observeEvent(DataFrom(), {
      # req(Actived())
      updatePickerInput(
        session = session, inputId = 'Sample', choices = names(DataFrom()) [-AllLines()],
        selected = names(DataFrom()) [-AllLines()]
      )
    })
    
    output$Gene <- renderUI({
      # req(Actived())
      if(Analysis != 'Basic'){
        pickerInput(
          NS(id, 'GeneName'), label = 'Genes', choices = unique(DataFrom() [['Gene.Name']]),
          selected = unique(DataFrom() [['Gene.Name']]),
          options = list(
            `actions-box` = TRUE,
            `selected-text-format` = "count > 3"
          ),
          multiple = TRUE
        )
      }
    })
    
    NewDat <- reactive({
      # req(input$Sample, Actived())
      
      if(Analysis == 'Basic') {
        DataFrom() %>% select((AllLines()), any_of(input$Sample))
      } else {
        req(input$Sample, input$GeneName)
        DataFrom() %>% select((AllLines()), any_of(input$Sample)) %>%
          filter(`Gene.Name` %in% input$GeneName)
      }
      
    })
    
    origPlot <- 
      reactive({
        if(Analysis == 'Basic')
        {
          get_sample_Ms_or_Hete(
            Functs = if_else(
              Type == 'Missing Rate', 'cal_each_col_na_percent', 'cal_each_col_Heterozygosity_percent'
            ), 
            plotdata = NewDat(), 
            Xlab = Type
          )
        } else {
          SGFSPlotting(NewDat())
        }
      })
    origPlot
  })
}

