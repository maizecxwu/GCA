
# use tabSetpanel
# The Tools one
# funtion one:
# upload usr's original .csv data, ask whether to change the seq name to line name
# change, create a ui to upload the seqName-LineName table (.xlsx) and reheader the LineName
# give a button to transform the strand to the B73 V4 ref format
# give a notification or progressbar when transforming
# library(shiny)
# library(tidyverse)
# library(magrittr)
# library(reactable)
# library(showtext)
# library(patchwork)
# library(gdsfmt)
# library(SNPRelate)
# library(LEA)
# library(colourpicker)
# library(shinyWidgets)
# library(shinycssloaders)
# library(pheatmap)
# library(ggstar)
# library(shinythemes)
# library(gg.gap)
# source("http://membres-timc.imag.fr/Olivier.Francois/Conversion.R")
# source("http://membres-timc.imag.fr/Olivier.Francois/POPSutilities.R")
# 
# options(shiny.maxRequestSize = 100 * 1024^2)

GCA <- function(...) {
  
  ## All Pages UI 
  UIone <-
    tabPanel(
      h4(strong("Formatting")),
      tags$head(
        tags$style(HTML("hr {border-top: 3px solid #000000;}"))
      ),
      sidebarLayout(
        sidebarPanel(
          width = 3,
          fluidRow(
            shinyjs::useShinyjs(),
            shinyFeedback::useShinyFeedback(),
            h3(strong('Data preprocessing Options')),
            NewSwitch(inputId = 'CName', label = h4(strong('Formatting?'))),
            NewSwitch(inputId = 'CName2', label = h4(strong('Change Name?'))),
            a(id = "DetailFormat", h4("Required Format Options"),  href = "#"),
            shinyjs::hidden(
              div(
                id = 'ShoworHiede',
                textInput(
                  inputId = 'Suffix', label = 'The prefix(suffix) to remove', placeholder = 'prefix|suffix (Separated by |)', value = '.Top Alleles'
                ),
                numericInput('LineStartCol', label = 'The Start Column Num of Line', value = 4),
                textInput('ChrName', 'Column Name of CHR', value = "Chr"),
                textInput('PosName', 'Column Name of Position', value = "Position")
              )
            ),
            NewSwitch(inputId = 'TTPS', label = h4(strong('Transform to plus strand?')))
          ),
          fluidRow(
            hr(),
            readextFileUI('Gfile', format = '.csv'),
            # actionButton('CSTL', 'Change SeqName to LineName?'),
            readextFileUI('LineName', format = '.xlsx')
          ),
          fluidRow(
            hr(),
            h3(strong('Transformmed File Download')),
            downloadUI('download1', 'Csv File Download!'),
            p(),
            downloadUI('download2', 'gzvcf File Download!'),
            h3(strong('Gchip File Demo (Formatted)')),
            reactableOutput('demoTable')
          )
        ),
        mainPanel(width = 9,
                  HeatMapUI('chipheatmap')
        )
      )
    )
  
  
  
  UItwo <- 
    tabPanel(
      h4(strong("Statistics")),
      fluidRow(
        column(width = 6,
               fluidRow(
                 column(width = 4,
                        h4(style = "text-align: center;", strong('MissingRate Options')),
                        availPlotUI('MSRT'),
                        PlotModifyUI('MSRT')
                 ),
                 column(width = 4,
                        h4(style = "text-align: center;", strong('Heterozygosity Options')),
                        availPlotUI('HeteRT'),
                        PlotModifyUI('HeteRT')
                 ),
                 column(width = 4,
                        h4(style = "text-align: center;", strong('File Download Options')),
                        br(downloadUI('download3', 'FunctionGene File download!')),
                        br(PicturedownloadUI('MSRT', 'MissingRate Plot Download')),
                        br(PicturedownloadUI('HeteRT', 'Heterozygosity Plot Download')),
                        br(PicturedownloadUI('FGSplot', 'FunctionGene Plot Download'))
                 )
               ),
               fluidRow(
                 column(width = 6,
                        plotOutput('MSRT')
                 ),
                 column(width = 6,
                        plotOutput('HeteRT')
                 )
               )
        ),
        column(
          width = 6,
          fluidRow(
            h4(style = "text-align: center;", strong('FunctionGene Options')),
            column(
              width = 6,
              availPlotUI('FGSplot')
            ),
            column(
              width = 6,
              PlotModifyUI('FGSplot')
            )
          ),
          shinycssloaders::withSpinner(plotOutput('FGSplot', height = "600px"))
        )
      )
    )
  
  UIthree <- 
    tabPanel(
      h4(strong("PRI")),
      sidebarLayout(
        sidebarPanel(width = 3,
                     NewSwitch(inputId = 'UseBefore', label = h4(strong('use data from formatting?'))),
                     a(id = 'PRIself', h4("Upload your vcf(.gz) file?")),
                     shinyjs::hidden(
                       div(id = 'PRIselfFile',
                           readextFileUI('NewGfile', format = c('.vcf', '.vcf.gz')),
                       )
                     ),
                     hr(),
                     h4(style = "text-align: center;", strong('IBD Table')),
                     reactableOutput('Ibd'),
                     hr(),
                     h4(style = "text-align: center;", strong('File Download')),
                     map(
                       c('IBD', 'IBS', 'Kinship', 'Admixture'),
                       ~ tagList(
                         downloadUI(str_c(.x, 'download'), str_c(.x, ' downloading!')),
                         p()
                       )
                     ),
                     hr(),
                     h4(style = "text-align: center;", strong('Plot Download')),
                     br(PicturedownloadUI('IBS', 'IBS Plot Download')),
                     br(PicturedownloadUI('Kinship', 'Kinship Plot Download')),
                     br(PicturedownloadUI('ADM', 'ADM Plot Download'))
        ),
        mainPanel(
          width = 9,
          sidebarLayout(
            mainPanel(
              width = 8,
              fluidPage(
                fluidRow(
                  h3(style = "text-align: center;", strong('IBS Heatmap Plot')),
                  column(width = 3,
                         SelectSampleUI('IBS'),
                         PlotModifyUI('IBS')
                  ),
                  column(width = 9,
                         shinycssloaders::withSpinner(plotOutput('IBS'))
                  )
                ),
                hr(),
                fluidRow(
                  h3(style = "text-align: center;", strong('Kinship Heatmap Plot')),
                  column(width = 3,
                         SelectSampleUI('Kinship'),
                         PlotModifyUI('Kinship')
                         
                  ),
                  column(width = 9,
                         shinycssloaders::withSpinner(plotOutput('Kinship'))
                  )
                )
              ),
              hr(),
              h3(style = "text-align: center;", strong('Input POP Name By Yourself')),
              fluidRow(uiOutput('NameUI'))
            ),
            sidebarPanel(
              width = 4,
              fluidPage(
                h3(style = "text-align: center;", strong('Population structure Plot')),
                fluidRow(
                  shinycssloaders::withSpinner(plotOutput('ADM', height = "600px"))
                ),
                fluidRow(
                  PlotModifyUI('ADM'),
                  sliderInput('PopNum', 'Cluster Num', min = 1, max = 20, value = 3),
                  sliderInput('TextSize', 'POP Size', min = 2, max = 15, value = 6)
                )
              )
            )
          )
        )
      )
    )
  
  UIfourth <-
    tabPanel(
      h4(strong("PCA")),
      tags$head(
        tags$style(HTML("hr {border-top: 3px solid #000000;}"))
      ),
      sidebarLayout(
        sidebarPanel(width = 3,
                     NewSwitch(inputId = 'PCAdata', label = h4(strong('use data from formatting?')), defaultValue = TRUE),
                     NewSwitch(inputId = 'PCAdata2', label = h4(strong('use AMP as background?')), defaultValue = TRUE),
                     textInput(inputId = 'UserBackName', label = 'Background Name', placeholder = 'eg. AMP', value = 'AMP'),
                     a(id = 'UpGFile1and2', br(h4('Upload 2 Genotype Files by yourself')), href = '#'),
                     shinyjs::hidden(
                       div(
                         id = 'GFile1and2',
                         readextFileUI('GenotypeFile', format = c('.vcf', '.vcf.gz')),
                         readextFileUI('GenotypeFile2', format = c('.vcf', '.vcf.gz')),
                       )
                     ),
                     downloadUI('Merge2Paneldownload', 'Merge2Panel downloading!'),
                     hr(),
                     br(h3(strong('PCA plotting required file'))),
                     readextFileUI('CoreLinefile', format = '.xlsx'),
                     readextFileUI('HighLightfile', format = '.xlsx'),
                     NewSwitch(inputId = 'noshowamp', label = h4(strong('No showing Background?'))),
                     hr(),
                     sliderInput('PCA1', 'PC x', min = 1, max = 30, value = 1),
                     sliderInput('PCA2', 'PC y', min = 1, max = 30, value = 2),
                     PlotModifyUI('origplot')
        ),
        mainPanel(width = 9,
                  tags$head(tags$style(
                    HTML("
                .shiny-output-error-validation {
                  color: green;
                }
              ")
                  )),
                  h3(textOutput('MergeCount')),
                  fluidRow(
                    column(width = 3,
                           sliderInput('PointSizeBB', 'HighLight Point size', min = 0, max = 10, value = 6),
                           sliderInput('PointSizeS', 'BackGround Point size', min = 0, max = 10, value = 3)
                    ),
                    column(width = 3,
                           sliderInput('PointAlphaBB', 'HighLight Point Alpha', min = 0, max = 1, value = 0.8),
                           sliderInput('PointAlphaS', 'BackGround Point Alpha', min = 0, max = 1, value = 0.2)
                    ),
                    column(width = 3,
                           sliderInput('LegendSize', 'Legend Size', min = 0, max = 20, value = 8),
                           sliderInput('LabelSize', 'Label Size', min = 0, max = 12, value = 5)
                    ),
                    column(width = 3,
                           NewSwitch(inputId = 'PickColor', label = h4(strong('Pick Color by yourself?'))),
                           NewSwitch(inputId = 'PickShape', label = h4(strong('Pick Shape by yourself?'))),
                           PicturedownloadUI('PCAPdownload', 'PCA picture download')
                    )
                  ),
                  fluidRow(uiOutput('colorUI')),
                  fluidRow(uiOutput('shapeUI')),
                  shinycssloaders::withSpinner(plotOutput('finalPCAplot', height = "800px"))
        )
      )
    )
  
  
  
  # Define UI for application that draws a histogram
  ui <- navbarPage(
    h4(strong("GCA (Gene Chip Analysis)")),
    id = 'GCA',
    # selected = 'Formatting',
    UIone,
    UItwo,
    UIthree,
    UIfourth
  )
  
  # Define server logic required to draw a histogram
  server <- function(input, output, session) {
    
    origDat <- readextFileServer('Gfile')
    
    shinyjs::onclick("DetailFormat",
                     shinyjs::toggle(id = "ShoworHiede", anim = TRUE))   
    
    
    Chipdata <- 
      reactive({
        # req(input$GCA == 'Formatting')
        
        if (input$CName)
        {
          # 是否要改名字
          if(input$CName2)
          {
            LineNamedata <- readextFileServer('LineName')
            ### 改名字，就需要移除前后缀
            # 提取测序ID的前后缀
            GT_NAME <- str_remove_all(colnames(origDat()) [-c(1:(input$LineStartCol - 1))], input$Suffix)
            # 判断被测序的ID是否和用户提供的一致
            IDTL <- identical(sort(GT_NAME), sort(LineNamedata()$SEQID))
            # 判断用户提供的前后缀是否有效
            PrefixNotRight <- !identical(GT_NAME, colnames(origDat())[-c(1:(input$LineStartCol - 1))])
          } else {
            ### 不改名字，就不需要移除前后缀
            GT_NAME <- colnames(origDat()) [-c(1:(input$LineStartCol - 1))]
            IDTL <- TRUE
            PrefixNotRight <- TRUE
            LineNamedata <- reactive('NULL')
          }
          
          # 判断用户提供的染色体列名是否存在
          ChrNameExist <- input$ChrName %in% colnames(origDat())
          # 判断用户提供的位置列名是否存在
          PosNameExist <- input$PosName %in% colnames(origDat())
          
          # 使用反馈函数进行反馈
          shinyFeedback::feedbackDanger(
            "ChrName", !ChrNameExist, "The Column no existing!"
          )
          
          shinyFeedback::feedbackDanger(
            "PosName", !PosNameExist, "The Column no existing!"
          )
          
          shinyFeedback::feedbackDanger(
            "Suffix", !PrefixNotRight, "The Suffix no right!"
          )
          
          shinyFeedback::feedbackDanger(
            "LineStartCol", !IDTL, "Sequenced ID is not identical to the ID User supply!"
          )
          
          # 确保以上四点都正确后，再进行操作
          req(IDTL, PrefixNotRight, ChrNameExist, PosNameExist, cancelOutput = TRUE)
          
          # 根据测序和自交系名称，对原始下机文件的测序ID进行替换
          # 同时还会完成格式修改工作，比如SNP ID修改，--替换为NA等
          TranOrigToNewGchipCsv(
            origDat(), LineNamedata(),
            Prefix_Suffix = input$Suffix,
            LineStartCol = input$LineStartCol,
            ChrName = input$ChrName,
            PosName = input$PosName
          )
        } else {
          origDat()
        }
      })
    
    TransformedChipdata <-
      reactive({
        # req(Chipdata())
        if (input$TTPS)
        {
          req(input$CName) # 正负链转换之前，必须要做格式化
          
          id <- showNotification('GT Transformming!', duration = NULL)
          on.exit(removeNotification(id), add = TRUE)
          # 该函数仅对双绿源的测序结果发挥功能
          # 可以进行负链探针结果矫正到正链
          TO_REF_GT_V2(Chipdata())
        } else {
          list(
            CsvFormat = Chipdata(),
            # 该函数可以对格式正确的芯片结果转为vcfR格式
            vcfFormat = TO_REF_GT_V2_VCF(Chipdata())
          )
        }
      })
    
    
    CsvFormatData <- reactive(TransformedChipdata() [['CsvFormat']])
    VcfFormatData <- reactive(TransformedChipdata() [['vcfFormat']])
    
    HeatMapServer('chipheatmap', VcfFormatData)
    
    downloadServer('download1', 'Transformed_REF_STRAND_GT.csv', CsvFormatData(), 'csv')
    
    downloadServer('download2', 'Transformed_REF_STRAND_GT.vcf.gz', VcfFormatData(), 'vcf')
    
    output$demoTable <- renderReactable({
      GchipDemoReacTable
    })
    
    ### Statistcs
    
    GCAfunctionInf <-
      reactive({
        GetAllSampleFunctionGene(CsvFormatData())
      })
    
    MSRTOrigPlot <-
      availPlotServer(
        'MSRT', DataFrom = CsvFormatData,
        Type = 'Missing Rate'
      )
    
    MSRTPlot <- PlotModifyServer(
      'MSRT', MSRTOrigPlot
    )
    
    output$MSRT <- renderPlot({
      PicturedownloadServer('MSRT', MSRTPlot())
      MSRTPlot()
    })
    
    HeteRTOrigPlot <-
      availPlotServer(
        id = 'HeteRT', DataFrom = CsvFormatData,
        Type = 'Heterozygosity'
      )
    
    HeteRTPlot <-PlotModifyServer(
      'HeteRT', HeteRTOrigPlot
    )
    
    output$HeteRT <- renderPlot({
      PicturedownloadServer('HeteRT', HeteRTPlot())
      HeteRTPlot()
    })
    
    # Function Gene Analysis
    
    downloadServer('download3', 'FunctionGeneInformation.csv', GCAfunctionInf(), 'csv')
    
    FGSplotOrigPlot <- availPlotServer(
      'FGSplot', DataFrom = GCAfunctionInf, Analysis = 'FGS'
    )
    
    FGSPLOT <- PlotModifyServer(
      'FGSplot', FGSplotOrigPlot
    )
    
    output$FGSplot <- renderPlot({
      PicturedownloadServer('FGSplot', FGSPLOT())
      FGSPLOT()
    })
    
    ### Relationship inference
    
    shinyjs::onclick("PRIself",
                     shinyjs::toggle(id = "PRIselfFile", anim = TRUE)) 
    
    NewFile <-
      reactive({
        # req(Chipdata())
        if (input$UseBefore)
        {
          VcfFormatData()
        } else {
          MIDFILE <- readextFileServer('NewGfile')()
        }
      })
    
    gdsFile <- reactive({
      req(NewFile())
      GetgdsFile(NewFile())
    })
    
    
    IBDfile <- reactive(ibdCal(gdsFile()))
    
    IBSfile <- reactive(ibsCal(gdsFile()))
    
    Kinshipfile <- reactive(kinshipCal(gdsFile()))
    
    Admixturefile <- reactive(AdmixtureCal(NewFile(), Knum = input$PopNum))
    
    map(
      c('IBD', 'IBS', 'Kinship', 'Admixture'),
      ~ downloadServer(
        str_c(.x, 'download'), str_c(.x, '.csv'), get(str_c(.x, 'file'))()
      )
    )
    
    # IBD table
    output$Ibd <- renderReactable({
      reactable(
        IBDfile() %>% mutate(across(3:5, round, digits = 4))
      )
    })
    # IBS plot
    SelectSampleIBS <- SelectSampleServer('IBS', IBSfile)
    
    PlotIBS <- reactive(PlotTriheatmaps(SelectSampleIBS()))
    
    modifyIBS <- PlotModifyServer(
      'IBS', PlotIBS
    )
    
    output$IBS <- renderPlot({
      req(modifyIBS())
      PicturedownloadServer('IBS', modifyIBS())
      modifyIBS()
    })
    
    # kinship Plot
    SelectSampleKinship <- SelectSampleServer('Kinship', Kinshipfile)
    
    PlotKinship <- reactive(PlotTriheatmaps(SelectSampleKinship()))
    
    modifyKinship <- PlotModifyServer(
      'Kinship', PlotKinship
    )
    
    output$Kinship <- renderPlot({
      req(modifyKinship())
      PicturedownloadServer('Kinship', modifyKinship())
      modifyKinship()
    })
    
    # Admixture Plot
    
    AllNames <- reactive(levels(Admixturefile()$PC))
    
    output$NameUI <- renderUI({
      req(AllNames())
      
      WIDTHs3 <- as.integer(12 / length(AllNames()))
      
      fluidRow(
        map(
          AllNames(), ~ column(width = WIDTHs3, textInput(.x, .x)
          )
        )
      )
    })
    
    PCname <- reactive(map_chr(AllNames(), ~ input [[.x]] %||% str_replace(.x, 'PC', 'K')))
    
    PlotADM <- reactive(PlotBarPlot(Admixturefile(), PCname = PCname(), TextSize = input$TextSize))
    
    modifyADM <- PlotModifyServer(
      'ADM', PlotADM
    )
    
    output$ADM <- renderPlot({
      PicturedownloadServer('ADM', modifyADM())
      modifyADM()
    })
    
    ### PCA
    PCAfile1 <-
      reactive({
        # input$PCAdata2
        if(input$PCAdata)
        {
          VcfFormatData()
        } else {
          readextFileServer('GenotypeFile')()
        }
      })
    
    PCAfile2 <-
      reactive({
        if(input$PCAdata2)
        {
          AMP_sample
        } else {
          readextFileServer('GenotypeFile2')()
        }
      })
    
    # decide upload Gfile by yourself
    shinyjs::onclick("UpGFile1and2",
                     shinyjs::toggle(id = "GFile1and2", anim = TRUE))  
    
    MergedPCAfile <- reactive({
      req(PCAfile1(), PCAfile2())
      OverlapPanel(PCAfile1(), PCAfile2())
    })
    
    downloadServer(
      'Merge2Paneldownload', 'Merge2Panel.vcf.gz', MergedPCAfile(), fileExt = 'vcf.gz'
    )
    
    output$MergeCount <- renderText({
      req(PCAfile1(), PCAfile2())
      if(req(nrow(PCAfile1()) != 0 & nrow(PCAfile2()) != 0))
      {
        str_c(
          "Sample Count: ", (ncol(`@`(MergedPCAfile(), 'gt')) - 1), '       ',
          "Snp Count: ", nrow(`@`(MergedPCAfile(), 'gt'))
        )
      }
    })
    
    MergedgdsFile <- reactive({
      GetgdsFile(MergedPCAfile())
    }
    )
    
    PCAINF <-
      reactive({
        GetPCA(MergedgdsFile())
      })
    
    CoreLinefile <- readextFileServer('CoreLinefile')
    
    HighLightfile <- readextFileServer('HighLightfile')
    
    # 根据用户选择是否用AMP作为背景，来决定是否使用AMP作为背景形状的名称
    BackgroundName = reactive(if_else(input$PCAdata2, 'AMP', input$UserBackName))
    
    ### 根据用户需要群个数，创建对应数目的颜色选项
    # 首先判断核心自交系的群和用户自选群的数目
    CoreLineGroup <- reactive(unique(CoreLinefile()$Group))
    
    UserLineGroup <- reactive({
      UserLine <- 
        HighLightfile() %>%
        filter(!(Line %in% CoreLinefile()$Line)) %>%
        filter(is.na(RmLine))
      # 如果用户输入的材料分群中有和核心群重叠的，直接排除在外
      setdiff(unique(UserLine$Group), unique(CoreLinefile()$Group))
    })
    
    AllColors <- reactive(c(CoreLineGroup(), UserLineGroup()))
    
    output$colorUI <- renderUI({
      
      req(AllColors())
      
      if(input$PickColor)
      {
        WIDTHs <- as.integer(12 / length(AllColors()))
        
        fluidRow(
          map(
            AllColors(),
            ~ column(width = WIDTHs,colourInput(.x, .x))
          )
        )
      }
    })
    
    ColorByUser <- reactive({
      if(input$PickColor)
      {
        list(
          map_chr(CoreLineGroup(), ~ input [[.x]] %||% "white"),
          map_chr(UserLineGroup(), ~ input [[.x]] %||% "white")
        )
      } else {
        list(
          colorRampPalette(c(col_10, 'black'))(length(CoreLineGroup())),
          colorRampPalette(DeepColor)(length(UserLineGroup()))
        )
      }
    })
    
    ### 根据用户自定义形状个数，创建对应数目的形状选项
    AllShape <- reactive(
      c(
        str_c(c('', 'non-'), input$UserBackName),
        HighLightfile() %>%
          filter(!(Line %in% CoreLinefile()$Line)) %>%
          filter(is.na(RmLine)) %$% unique(na.omit(Shapes))
      )
    )
    
    output$shapeUI <- renderUI({
      req(AllShape())
      
      if(input$PickShape)
      {
        WIDTHs2 <- as.integer(12 / length(AllShape()))
        
        fluidRow(
          map(
            AllShape(),
            ~ column(width = WIDTHs2,
                     selectInput(.x, .x, choices = AllShapeForm$Shape)
            )
          )
        )
      }
    })
    
    shapeByUser <- reactive({
      if(input$PickShape)
      {
        map_chr(AllShape(), ~ input [[.x]] %||% "circle")
      } else {
        c('circle', 'regular triangle',
          AllShapeForm$Shape [-c(11, 15)]) [1:length(AllShape())]
      }
    })
    
    origPCAplot <-
      reactive({
        if(req(!any(unlist(ColorByUser()) %in% 'white')))
        {
          GetPACplot(
            PCAINF(), input$PCA1, input$PCA2, CoreLinefile(), HighLightfile(),
            input$noshowamp,
            SizeList = c(input$PointSizeBB, input$PointSizeS),
            AlphaList = c(input$PointAlphaBB, input$PointAlphaS),
            LegendLabelSize = c(input$LegendSize, input$LabelSize),
            CoreGroupColor = ColorByUser() [[1]],
            UsrdefaultColor = ColorByUser() [[2]],
            UserShapes = shapeByUser(),
            BackgroundName = BackgroundName()
          )
        }
      })
    
    modifyPCAplot <-
      PlotModifyServer('origplot', origPCAplot)
    
    output$finalPCAplot <- renderPlot({
      req(PCAfile1(), PCAfile2(), HighLightfile(), CoreLinefile())
      if(req(nrow(PCAfile1()) != 0 & nrow(PCAfile2()) != 0, HighLightfile()))
      {
        ## check if there are Line not exiting AMP and USRINF
        NotIncludeLine <-
          PCAINF()[['Vec']] [['Line']] [
            which(!(
              PCAINF()[['Vec']] [['Line']] %in% 
                unique(
                  c(AMP_source$Lines, HighLightfile()$Line, CoreLinefile()$Line)
                )
            ))
          ]
        
        if(length(NotIncludeLine) != 0)
        {
          validate(str_c('These Line (', str_c(NotIncludeLine, collapse = ','), ') does not exits in HighLightfile!'))
        } else {
          
          PicturedownloadServer('PCAPdownload', modifyPCAplot())
          modifyPCAplot()
        }
        
      }
    })
    
  }
  
  shinyApp(ui = ui, server = server, ...)
}

