
PheatMapplot <- function(TestFIle, RandomSize = 1000, SampleName = colnames(TestFIle@gt) [-1], SampletextSize = 10) {
  
  PlotDat <-
    cbind(
      TestFIle@fix [, 'ID', drop = F],
      TestFIle@gt [, -1]
    ) %>% as_tibble() %>%
    select(-ID) %>% select(all_of(SampleName))
  
  PlotDat2 <-
    map_df(PlotDat, function(x) {
      x [x == '0/0'] <- '0'
      x [x == '1/1'] <- '1'
      x [x == '0/1'] <- '2'
      x [!(x %in% c('0', '1', '2'))] <- '3'
      as.numeric(x)
    }) %>% as.data.frame()
  
  rownames(PlotDat2) <- TestFIle@fix [, 'ID']
  
  Randomnum <- 
    sample(1:nrow(PlotDat2), size = RandomSize)
  
  pheatmap(
    PlotDat2 [Randomnum, , drop = F], show_rownames = FALSE,
    color = c(Four_Type_color),
    border_color = NA,
    legend_breaks = c(0, 1, 2, 3),
    legend_labels = c('ref', 'alt', 'ref/alt', 'none'), 
    breaks = c(-0.5, 0.5, 1.5, 2.5, 3.5),
    fontsize = SampletextSize
  )
}

