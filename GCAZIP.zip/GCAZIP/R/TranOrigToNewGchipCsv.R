

TranOrigToNewGchipCsv <- function(GT, LINE_INF, Prefix_Suffix, LineStartCol, ChrName, PosName) {
  
  # 先移除用户输入的，由于测序公司添加的前后缀
  
  if(nchar(Prefix_Suffix) == 0)
  {
    GT_NAME <- colnames(GT) [-c(1:(LineStartCol - 1))]
  } else {
    GT_NAME <-
      str_remove_all(colnames(GT) [-c(1:(LineStartCol - 1))], Prefix_Suffix)
  }
  
  ## 所有名称中的空格必须删除，否则后续会被影响
  GT_NAME <- GT_NAME %>% str_remove_all(' ')
  
  # 
  # # 检验下机得到的自交系是否和用户原始提供的一致
  # if(!identical(sort(GT_NAME), sort(LINE_INF$SEQID)))
  # {
  #   stop('Your sequencing ID is not identical to record ID !\n Please Check Them Again !')
  # }
  # 
  # 前面没有问题，则将测序ID替换为自交系名称
  if(LINE_INF != 'NULL')
  {
    colnames(GT) [LineStartCol:ncol(GT)] <- 
      LINE_INF$LINE[
        match(GT_NAME, LINE_INF$SEQID) 
      ]
  } else {
    colnames(GT) [LineStartCol:ncol(GT)] <- GT_NAME
  }
  
  # 测序公司给的除了染色体名称，位置名称的其他列名，不包含材料名称
  OTherInf <- setdiff(colnames(GT) [1:(LineStartCol - 1)], c(ChrName, PosName, 'ID'))
  
  # 根据用户提供的染色体名称，以及位置名称所在列，创造ID名称，并剔除其他列
  GT_V1 <-
    GT %>% mutate(ID = str_c('chr', .data [[ChrName]], '.s_', .data [[PosName]])
    ) %>% select(all_of(c(ChrName, PosName, 'ID')), everything()) %>%
    select(-any_of(OTherInf))
  
  colnames(GT_V1) [1:2] <- c('#CHROM', 'POS') 
  
  # Format All no SNP genotypes to NA
  
  GT_V2 <- GT_V1 [, -c(1:3), drop = F] 
  
  Formatted_GT <- 
  cbind(
    GT_V1 [, c(1:3)],
    map_df(GT_V2, function(x) {
      x [!(x %in% AllBaseCombinations())] <- NA
      x
    })
  )
  
  Formatted_GT
  
  
}
