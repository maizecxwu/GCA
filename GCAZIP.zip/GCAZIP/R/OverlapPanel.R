
OverlapPanel <- function(file1, file2) {
  
  FrontGT <- cbind(file1@fix [, -c(6:ncol(file1@fix))], file1@gt [, -1]) %>% as_tibble(.name_repair = 'minimal')
  BackGT <- cbind(file2@fix, file2@gt) %>% as_tibble(.name_repair = 'minimal')
  
  ## 前景中，直接剔除掉所有与背景重叠的Line
  
  Mergefile <- 
  inner_join(
    BackGT,
    FrontGT %>% select(-any_of(colnames(file2@gt [, -1]))),
    by = c(
      'CHROM' = 'CHROM', 'POS' = 'POS', 'ID' = 'ID',
      'REF' = 'REF', 'ALT' = 'ALT'
    )
  )
  
  NewAMP_sample <- AMP_sample
  
  NewAMP_sample@fix <-
  Mergefile %>% select(CHROM:INFO) %>% as.matrix()
  
  NewAMP_sample@gt <- 
  Mergefile %>% select(-c(CHROM:INFO)) %>% as.matrix()
  
  NewAMP_sample
}
